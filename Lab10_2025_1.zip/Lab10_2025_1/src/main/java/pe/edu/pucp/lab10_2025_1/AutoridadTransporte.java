/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pe.edu.pucp.lab10_2025_1;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

/**
 *
 * @author enric
 */
public class AutoridadTransporte {
    private List<Propietario> propietarios;
    private List<Vehiculo> vehiculos;
    private List<Captura> capturas;
    private List<RegistroInfraccion> regInfracciones;
    private Scanner archivo;
    public AutoridadTransporte(String nameArchive) throws FileNotFoundException{
        propietarios=new ArrayList<>();
        vehiculos=new ArrayList<>();
        capturas=new ArrayList<>();
        regInfracciones=new ArrayList<>();
        File archive=new File(nameArchive);
        archivo=new Scanner(archive);
    }
    public void cargarDatos(){
        this.cargarPropietarios();
    }
    public void cargarPropietarios(){
        String separador="FIN";
        while(this.archivo.next()!=separador){
            Propietario nuevoPropietario=new Propietario();
            nuevoPropietario.cargar(archivo);
        }
    }
    
}
