//
// Created by enric on 28/10/2025.
//
#include <iostream>
#include <fstream>
using namespace std;
#include "Restaurante.h"
Restaurante::Restaurante() {
    clientes=nullptr;
    cantidadClientes=0;
    capacidadPlatos=0;
    platos=nullptr;
    cantidadPlatos=0;
    capacidadPlatos=0;
}
Restaurante::~Restaurante() {
    if (clientes!=nullptr) delete [] clientes;
    if (platos!=nullptr) delete [] platos;
}

void Restaurante::incrementarEspacioClientes() {
    cantidadClientes+=5;
    if (clientes==nullptr) {
        cantidadClientes=1;
        clientes=new Cliente[cantidadClientes]{};
    }else {
        Cliente *clientesLocal=new Cliente[cantidadClientes];
        for (int i=0;i<cantidadClientes;i++) {
            clientesLocal[i]=clientes[i];
        }
        delete [] clientes;
        clientes=clientesLocal;
    }
}

void Restaurante::incrementarEspacioPlatos() {
    cantidadPlatos+=5;
    if (platos==nullptr) {
        cantidadPlatos=1;
        platos=new Plato[cantidadPlatos];
    }else {
        Plato *platosLocal=new Plato[cantidadPlatos];
        for (int i=0;i<cantidadPlatos;i++) {
            platosLocal[i]=platos[i];
        }
        delete [] platos;
        platos=platosLocal;
    }
}

void operator<(Restaurante &restaurante, const char *nomArch) {
    ifstream arch;
    aperturaIfstream(arch,nomArch);
    cout<<restaurante.capacidadClientes<<endl;
    while (true) {
        if (restaurante.capacidadClientes==restaurante.cantidadClientes) {
            restaurante.incrementarEspacioClientes();
        }
        arch>>restaurante.clientes[restaurante.cantidadClientes-1];
        if (arch.eof()) break;
        restaurante.cantidadClientes++;
    }
}

void operator<=(Restaurante &restaurante, const char *nomArch) {
    ifstream arch;
    aperturaIfstream(arch,nomArch);
    while (true) {
        if (restaurante.capacidadPlatos==restaurante.cantidadPlatos) {
            restaurante.incrementarEspacioPlatos();
        }
        arch>>restaurante.platos[restaurante.cantidadPlatos-1];
        if (arch.eof()) break;
        restaurante.cantidadPlatos++;
    }
}
