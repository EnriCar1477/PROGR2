//
// Created by enric on 19/11/2025.
//

#include "Estante.h"

Estante::Estante() {
    capacidad=0.0;
}

void Estante::setId(int id) {
    this->id=id;
}

void Estante::setCapacidad(double capacidad) {
    this->capacidad=capacidad;
}

void Estante::setClase(char clase) {
    this->clase=clase;
}

int Estante::getId() {
    return this->id;
}

double Estante::getCapacidad() {
    return this->capacidad;
}

void Estante::insertar(Libro *libro) {
    Llibros.insertar(libro);
}

bool Estante::verificar(Libro *libro) {
    if (capacidad>=libro->getPeso()+Llibros.getPeso()) return true;
    else return false;
}
