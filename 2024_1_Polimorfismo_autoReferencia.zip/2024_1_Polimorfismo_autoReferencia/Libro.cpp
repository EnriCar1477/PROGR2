//
// Created by enric on 19/11/2025.
//

#include "Libro.h"


Libro::Libro() {
    nombre=nullptr;
    paginas=0;
    peso=0.0;
}

Libro::~Libro() {
    liberarCadena(nombre);
}

double Libro::getPeso() {
    return peso;
}

void Libro::leer(ifstream &arch) {
    char title[100];
    arch.getline(title,100,',');
    arch>>paginas;
    arch.get();
    arch>>peso;
    arch.get();
    nombre=colectCadena(title);
}

