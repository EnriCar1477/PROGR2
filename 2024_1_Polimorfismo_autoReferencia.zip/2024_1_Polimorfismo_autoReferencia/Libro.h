//
// Created by enric on 19/11/2025.
//

#ifndef INC_2024_1_POLIMORFISMO_AUTOREFERENCIA_LIBRO_H
#define INC_2024_1_POLIMORFISMO_AUTOREFERENCIA_LIBRO_H

#include "Comunes.h"
class Libro {
private:
    char *nombre;
    int paginas;
    double peso;
public:
    Libro();
    virtual ~Libro();
    double getPeso();
    virtual void leer(ifstream &arch);

};


#endif //INC_2024_1_POLIMORFISMO_AUTOREFERENCIA_LIBRO_H