//
// Created by enric on 27/10/2025.
//

#ifndef L6_2023_2_POO_SOBRECARGAOPERADORES_COMUNES_H
#define L6_2023_2_POO_SOBRECARGAOPERADORES_COMUNES_H
char *extraerCadena(char *cadena) ;
void abrirArchivoIfstream(ifstream &arch,const char *nomArch);
void abrirArchivoOfstream(ofstream &arch,const char *nomArch) ;
#endif //L6_2023_2_POO_SOBRECARGAOPERADORES_COMUNES_H