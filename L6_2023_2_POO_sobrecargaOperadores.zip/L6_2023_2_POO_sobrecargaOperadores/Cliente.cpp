//
// Created by enric on 27/10/2025.
//
#include <iostream>
#include <fstream>
#include "Cliente.h"
#include "Comunes.h"
using namespace std;

Cliente::Cliente() {
    inicializar();
}
Cliente::~Cliente() {
    if (nombre!=nullptr) {
        delete nombre;
    }
}
void Cliente::inicializar(){
    dni=0;
    monto_total=0.0;
    cant_productos_entregados=0;
    nombre=nullptr;
}
bool operator >>(ifstream &arch,Cliente &cliente){
    arch>>cliente.dni;
    char nombre[100];
    if (arch.eof()) return false;
    arch.get();
    arch.getline(nombre,100,',');
    arch>>cliente.telefono;
    cliente.nombre=extraerCadena(nombre);
    return true;
}