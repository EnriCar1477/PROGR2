//
// Created by enric on 27/10/2025.
//

#include "Pedidos.h"

Pedidos::Pedidos() {
    codigo=nullptr;
    precio_producto=0.0;
}

Pedidos::~Pedidos() {
    if (codigo!=nullptr) delete codigo;
}
