//
// Created by enric on 27/10/2025.
//
#include <iostream>
#include "ProductoEntregado.h"
using namespace std;
#ifndef L6_2023_2_POO_SOBRECARGAOPERADORES_CLIENTE_H
#define L6_2023_2_POO_SOBRECARGAOPERADORES_CLIENTE_H
class Cliente {
private:
    int dni;
    char *nombre;
    int telefono;
    ProductoEntregado productos_entregados[20];
    int cant_productos_entregados;
    double monto_total;
public:
    Cliente();
    ~Cliente();
    void inicializar();
    friend bool operator >>(ifstream &arch,Cliente &cliente);
};


#endif //L6_2023_2_POO_SOBRECARGAOPERADORES_CLIENTE_H