//
// Created by enric on 27/10/2025.
//

#ifndef L6_2023_2_POO_SOBRECARGAOPERADORES_PRODUCTO_H
#define L6_2023_2_POO_SOBRECARGAOPERADORES_PRODUCTO_H


class Producto {
private:
    char *codigo;
    char *descripcion;
    double precio;
    int stock;
    int clientes_servidos[20];
    int clientes_no_servidos[20];
    int cant_clientes_servidos;
    int canti_clientes_no_servidos;
public:
    Producto();
    ~Producto();

};


#endif //L6_2023_2_POO_SOBRECARGAOPERADORES_PRODUCTO_H