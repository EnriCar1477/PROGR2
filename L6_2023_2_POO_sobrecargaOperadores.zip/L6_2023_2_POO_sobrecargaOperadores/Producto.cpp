//
// Created by enric on 27/10/2025.
//

#include "Producto.h"

Producto::Producto() {
    this->codigo=nullptr;
    this->precio=0.0;
    this->cant_clientes_servidos=0;
    this->canti_clientes_no_servidos=0;
    this->stock=0;
    this->descripcion=nullptr;
}

Producto::~Producto() {
    if (descripcion!=nullptr) {
        delete descripcion;
    }
    if (codigo!=nullptr) {
        delete codigo;
    }
}
