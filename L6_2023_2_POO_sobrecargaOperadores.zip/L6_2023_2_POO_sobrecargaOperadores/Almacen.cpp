//
// Created by enric on 27/10/2025.
//
#include <iostream>
#include <fstream>
#include "Almacen.h"
#include "Comunes.h"
#include "Cliente.h"
#include "Producto.h"
using namespace std;
Almacen::Almacen() {
    this->cantidad_clientes=0;
    this->cantidad_productos=0;
}
void Almacen::cargar_clientes() {
    ifstream arch;
    abrirArchivoIfstream(arch,"Clientes.csv");
    while (arch>>this->arreglo_clientes[this->cantidad_clientes]) this->cantidad_clientes++;
}
