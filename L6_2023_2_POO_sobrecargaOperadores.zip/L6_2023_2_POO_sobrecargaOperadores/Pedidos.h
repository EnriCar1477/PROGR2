//
// Created by enric on 27/10/2025.
//

#ifndef L6_2023_2_POO_SOBRECARGAOPERADORES_PEDIDOS_H
#define L6_2023_2_POO_SOBRECARGAOPERADORES_PEDIDOS_H


class Pedidos {
private:
    char *codigo;
    int dni_cliente;
    double precio_producto;
public:
    Pedidos();
    ~Pedidos();
};



#endif //L6_2023_2_POO_SOBRECARGAOPERADORES_PEDIDOS_H
