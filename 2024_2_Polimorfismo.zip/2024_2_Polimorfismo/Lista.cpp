//
// Created by enric on 12/11/2025.
//

#include "Lista.h"