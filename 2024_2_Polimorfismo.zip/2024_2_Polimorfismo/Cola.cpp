//
// Created by enric on 12/11/2025.
//

#include "Cola.h"

#include "Lista.h"

Cola::Cola() {
    longitud=0;
    cabeza=nullptr;
    cola=nullptr;
}

Cola::~Cola() {
    while (cabeza!=nullptr) {
        this->desencolar();
    }
}

void Cola::encolar(DetalleComandada comandada) {
    Nodo *nuevoNodo=new Nodo();
    nuevoNodo->dato=comandada;
    nuevoNodo->sig=nullptr;
    if (cabeza==nullptr) {
        cabeza=nuevoNodo;
        cola=cabeza;
    }else {
        cola->sig=nuevoNodo;
        cola=nuevoNodo;
    }
}

DetalleComandada Cola::desencolar() {
    if (this->cabeza!=nullptr) {
         Lista lista;
        lista.cabeza=this->cabeza;
        Nodo *recorrido=lista.cabeza;
        Nodo *anterior=nullptr;
        while (recorrido->sig!=nullptr) {
            anterior=recorrido;
            recorrido=recorrido->sig;
        }
        DetalleComandada desencolado=recorrido->dato;
        cola=anterior;
        delete recorrido;
        recorrido=nullptr;
        return desencolado;
    }


}

