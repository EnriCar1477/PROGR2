//
// Created by enric on 12/11/2025.
//

#include "Restaurante.h"

#include "Bebible.h"
#include "Entrada.h"

void Restaurante::cargar() {
    ifstream arch("comandas2.csv",ios::in);
    if(!arch.is_open()) {
        cout<<"Error ala abrir el archivo comandas2.csv"<<endl;
        exit(1);
    }
    DetalleComandada comanda;
    int id;
    char c,tipo;
    while (true) {
        arch>>id;
        if (arch.eof()) break;
        comanda.setId(id);
        arch>>c>>tipo>>c;
        Producto *prod;
        if (tipo=='B') {
            prod=new Bebible();
        }else if (tipo=='E') {
            prod=new Entrada();
        }else prod=new Proteina();
        prod->leer(arch);
        comanda.setProducto(prod);
        this->Ccomanda.encolar(comanda);
    }
}
