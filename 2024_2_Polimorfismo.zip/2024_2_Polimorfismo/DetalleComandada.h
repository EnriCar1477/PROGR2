//
// Created by enric on 12/11/2025.
//

#ifndef INC_2024_2_POLIMORFISMO_DETALLECOMANDADA_H
#define INC_2024_2_POLIMORFISMO_DETALLECOMANDADA_H

#include "Comunes.h"
#include "Proteina.h"

class DetalleComandada {
private:
    int id;
    Producto *pedido;
public:
    void setId(int id);

    void setProducto(Producto * prod);

    DetalleComandada();
    ~DetalleComandada();
};


#endif //INC_2024_2_POLIMORFISMO_DETALLECOMANDADA_H