//
// Created by enric on 12/11/2025.
//

#include "DetalleComandada.h"


DetalleComandada::DetalleComandada() {
    id = 0;
    pedido = nullptr;
}

DetalleComandada::~DetalleComandada() {
    if (pedido != nullptr) delete pedido;
}

void DetalleComandada::setId(int id) {
    this->id = id;
}

void DetalleComandada::setProducto(Producto *prod) {
    this->pedido = prod;
}
