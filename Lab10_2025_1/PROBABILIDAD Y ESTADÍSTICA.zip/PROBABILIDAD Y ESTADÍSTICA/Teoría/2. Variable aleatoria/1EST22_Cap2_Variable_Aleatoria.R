# Variable Aleatoria

#############
# Ejemplo 2 #
#############

# Función de probabilidad
f=function(x){0.48/(x+1)*(x>=0)*(x<=3)}

# Gráfico
x=0:3
plot(x,f(x),type="h",lwd=3,
     xlim=c(-0.5,3.5),
     ylim=c(0,1))
points(x,f(x),pch=16)

# Verificar Σ f(x) = 1
sum(p(0:3))

# P(X>=1) = Σ_x=1^3 f(x) = f(1) + f(2) + f(3)
sum(p(1:3))

# P(X>=1) = 1 - P(x=0) = 1 - f(0)
1-p(0)

# Función de distribución acumulada

F = function(x){
  Rx=0:3
  t = Rx[Rx<=x]
  sum(f(t))
}

F=Vectorize(F)

curve(F,-0.5,3.5,n=1001)


# P(X<3|X>0) = P(1<=X<3) / P(X>=1)
#            = (f(1)+f(2)) / (1-f(0)) 
(f(1)+f(2))/(1-f(0))

# Mediana: x_0.50
x=0:3
min(x[F(x)>=0.5])                

# Esperanza
# mu_X = E(X) = Σ_x x f(x)

(mu_X = sum(x*f(x)))


# E(X^2) = Σ_x x^2 f(x)

(E2  = sum(x^2*f(x)) )

# Varianza
# sigma2_x = Var(X) = E(X^2) - mu_x^2
(sigma2_X = E2-mu_X**2)

# Desviación Estándar
(sigma_X = sqrt(E2-mu_X**2))

# g(X): gastos por accidentes
# g(X)=1000X

# E(g(X)) = Σ_x g(x)*f(x)

g=function(x){1000*x}
x=0:3
sum(g(x)*f(x))

# Por propiedades
# E(X) = 1000 E(X)
1000*mu_X

#############
# Ejemplo 3 #
#############


# Función de densidad
f = function(x){x**2/55}

# Utilidad
# U = 120x+50(k-x)-85k, x<=k
#     35k             , x>k

U = function(x,k){
  (120*x+50*(k-x)-85*k)*(x<=k)+(35*k)*(x>k)  
}

# E(U(X,4))
x=1:5
sum(U(x,4)*f(x))

# E(U(X,k))

sum(U(x,1)*f(x))
sum(U(x,2)*f(x))
sum(U(x,3)*f(x))
sum(U(x,4)*f(x))
sum(U(x,5)*f(x))

#############
# Ejemplo 4 #
#############


# Función de densidad
f = function(x){(3/32)*(4-x**2)*(x>-2)*(x<2)}
curve(f(x),-2,2,col="red",lwd=2)

# P(-1<X<1)
integrate(f,-1,1)

# Función de distribución acumulada
F = function(x){
  (1/32)*(16+12*x-x**3)*(x>-2)*(x<2)+(x>=2)
}

curve(F,-3,3,col="red")

# P(X<0|X>-1) = P(-1<X<0)   F(0) - F(-1)
#               --------- = ------------
#                P(X>-1)      1 - F(-1)
#

(F(0)-F(-1))/(1-F(-1))

# Función de cuantiles
# La inversa de F(.) no tiene forma analítica.
# Utilizaremos métodos numéricos.

Q =function(p){
  F1 =function(x,p){
    F(x)-p
  }
  uniroot(F1,c(-2,2),p=p)$root
  }

# Mediana: x_0.50
Q(0.50)

# Cuantil 0.75: x_0.25
Q(0.75)

# E(X)
h  = function(x){x*f(x)} 
mu_X = integrate(h,-2,2)$value

# E(X^2)
h  = function(x){x**2*f(x)} 
E2 = integrate(h,-2,2)$value

# Var(X) = E(X^2) - E(X)^2
E2-mu_X^2

# g(X): costo por error de llenado
# g(X)=0.05|X|

g = function(x){0.05*abs(x)}

# E(g(X))
h  = function(x){g(x)*f(x)} 
integrate(h,-2,2)

#############
# Ejemplo 5 #
#############


# Función de densidad
f = function(x){2*x*(x>0)*(x<1)}

# Función de distribución acumulada
F = function(x){x^2*(x>0)*(x<1)+(x>=1)}

# Función de cuantiles
Q = function(p){sqrt(p)}

# Mediana: x_0.50
Q(0.5)

# Utilidad

U = function(x,t){
  (20*x-5*t)*(x<=t)+(15*t)*(x>t)
}

# E(U(X,0.8))
h=function(x){U(x,0.8)*f(x)}
integrate(h,0,1)

# k(t) = E(U(x,t)) = 15 t - 20 t^3 /3

k = function(t){15*t-20*t^3/3}
curve(k,0,1)

# Hallar k'(t)  = 15-20 t^2 = 0 ==> t = sqrt(0.75)
#        k''(t) = -40 t < 0 ==> se tiene un punto de máximo
# Solución: se maximiza la utilidad para t = sqrt(0.75)
sqrt(0.75)

# Numericamente:

optimize(k,lower=0,upper=1,maximum=TRUE)

#############
# Ejemplo 6 #
#############

# Lectura de datos
d=read.csv("accidentes_fab.csv")

# Función de probabilidad (Teórica)
p=function(x){
  0.48/(x+1)*(x>=0)*(x<=3)
  }

x=0:3
p(x)

# Función de probabilidad empírica 
prop.table(table(datos$accidentes))

# Gráfico - Función de probabilidad

plot(x,p(x),type="h",lwd=2,
     xlab = "x",
     ylab="Probabilidad")
lines(x+0.05,prop.table(tab),
      col="red",lwd=2,type="h")
legend("topright",pch=15,col=1:2,legend=c("Modelo","Datos"),
       bty="n")

# Función de distribución acumulada (Teórica)

F = function(x){
  Rx=0:3
  t = Rx[Rx<=x]
  sum(p(t))
}

F=Vectorize(F)

x=0:3
F(x)

# Función de distribución acumulada empírica

F_emp = ecdf(d$accidentes)
F_emp(x)
  
# Gráfico - Función de distribución acumulada
x=seq(-0.5,3.5,0.01)
plot(x,F(x),type="l",lwd=2,
     xlim=c(-0.5,3.5),lty=2,ylab="Probabilidad")
lines(ecdf(datos$accidentes),col="red",lwd=2,type="h")
legend("topleft",pch=15,col=1:2,legend=c("Modelo","Datos"),
       bty="n")

#############
# Ejemplo 7 #
#############

# Lectura de datos
d=read.csv("error.csv")

# Definir función de densidad teórica
f = function(x){(3/32)*(4-x^2)*(x>-2)*(x<2)}

##############
# Histograma #
##############

hist(d$error,breaks=20,probability = TRUE,
     main="",xlab="x",ylab="f(x)")

# Adicionar función de densidad teórica
curve(f,add = TRUE,col=2,lwd=2)

# Adicionar leyenda
legend("topright",pch=15,col=c(2,1),
       legend=c("Modelo","Datos"),
       bty="n")

###########################################
# Función de densidad empírica por kernel #
###########################################

plot(density(d$error),col=1,lwd=2,
     main="",xlab="x",ylab="f(x)")
# Adicionar función de densidad teórica
curve(f,add = TRUE,col=2,lwd=2)
# Adicionar leyenda
legend("topright",pch=15,col=c(2,1),
       legend=c("Modelo","Datos"),
       bty="n")

##############################################
# Función de distribución acumulada empírica #
##############################################

# Definir función de distribución acumulada teórica
F = function(x){(1/32)*(12*x-x**3+16)*(x>-2)*(x<2)+(x>=2)}

# Función de distribución acumulada empírica
plot(ecdf(d$error),col=2,lwd=4,
     main="",xlab="x",ylab="F(x)")

# Adicionar función de distribución acumulada empírica
curve(F,add = TRUE,col=1,lwd=2)

# Adicionar leyenda
legend("topleft",pch=15,col=1:2,legend=c("Modelo","Datos"),bty="n")

########################
# Gráfico de cuantiles #
########################

# Función de cuantiles
Q = function(p){
  F1 = function(x,p){
    F(x)-p
  }
  uniroot(F1,c(-2,2),p=p)$root
}
Q = Vectorize(Q)

# Gráfico de cuantiles
cuantil_muestral    = sort(d$error)
cuantil_poblacional = Q(ppoints(cuantil_muestral))
plot(cuantil_poblacional,cuantil_muestral)
abline(0,1,col=2,lwd=2)

#############
# Ejemplo 8 #
#############

u =runif(1000)

# Histograma
hist(u,prob=TRUE,main="Histograma")
curve(dunif,add=TRUE,col=2,lwd=2)
# Función de distribución acumulada empírica
plot(ecdf(u),main="Función de distribución acumulada empírica")
curve(punif,add=TRUE,col=2,lwd=2)
# Gráfico de cuantiles
cuantil_muestral    = sort(u)
cuantil_poblacional = qunif(cuantil_muestral)
plot(cuantil_poblacional,cuantil_muestral,main="Gráfico de cuantiles")
abline(0,1,col=2,lwd=2)

#############
# Ejemplo 9 #
#############

# Número de simulaciones
n = 100
# 1. Generar números aleatorios
u = runif(n)
# 2. Transformar
x = sqrt(u)

# Gráfico de cuantiles
cuantil_muestral    = sort(x)
cuantil_poblacional = sqrt(ppoints(x))  
plot(cuantil_poblacional,cuantil_muestral)
abline(0,1,col=2,lwd=2)

##############
# Ejemplo 10 #
##############

x = 0:3
f = 0.48/(x+1)
F = cumsum(f)
n = 1000
X<- numeric()
for (j in 1:n){
  u = runif (1)
  i = 0
  cont = 0
  while(cont==0){
    i = i+1
    if(u<F[i]){
      X[j] = x[i]
      cont = 1
    }
  }
}  

# Función de probabilidad
f

# Función de probabilidad empírica
prop.table(table(X))

##############
# Ejemplo 11 #
##############

# X = número de artículos defectuosos en una caja 12 unidades
# X ~ Binomial(12,0.01)
# P(En una caja aplique la garantía) = P(X>1)

# P(X>1) = 1 - P(X<=1)
#        = 1 - F_X(1)  

1 - pbinom(1,12,0.01)

# P(X>1) = 1 - P(X<=1)
#        = 1 - F_X(1)  
#        = 1 - f_X(0) - f_X(1)
1 - sum(dbinom(0:1,12,0.01))

# Y = número de cajas en las que aplica la garantía
#     de 4 vendidas

# Y ~ Binomial(4,p)
# donde p=P(X>1)=0.006174538

# P(Y=1)
p = 1 - sum(dbinom(0:1,12,0.01)) 
dbinom(1,4,p)

# W = número de cajas en las que aplica la garantía
#     de 1000 vendidas
# W ~ Binomial(1000,p)
# E(W) = 1000*p

1000*p

##############
# Ejemplo 12 #
##############

# Tasa de ocurrencia
lambda = 1/20 # terremotos por año

# X = número de terremotos en 100 años
# X ~ Poisson(mu) 
# con mu = lambda*t = (1/20)*100
# E(X) = mu
mu = lambda*100


# Y = número de terremotos en 50 años
# X ~ Poisson(mu) 
# con mu = lambda*t = (1/20)*50 = 2.5
# P(X>3) = 1 - F_X(3) = 1 -  Σ_{x=0}^{3} f_X(x)
mu = lambda*50
1 - ppois(3,mu)
1 - sum(dpois(0:3,mu))

# W = número de terremotos en t años
# W ~ Poisson(mu=lambda*t = t/20) 
# P(W=0) > 0.90
# exp(-t/20)>0.90
# t < -ln(0.90)*20 años

-log(0.90)*20

##############
# Ejemplo 13 #
##############

# Proceso de Poisson: ocurrencia de terremotos en el tiempo
# Tasa de ocurrencia
lambda = 1/20 # terremotos por año

# x = tiempo hasta que ocurra el primer terremoto
# X ~ Exp(lambda)
# P(X>30) = 1- F_X(30)
1-pexp(30,lambda)


# Y = tiempo hasta la ocurrencia de dos terremotos
# Y ~ Exp(lambda)
# E(Y)=1/lambda
1/lambda

# P(X>30|X>20) = P(X>20)    propiedad de falta de memoria
#              = 1- F_X(20)
1 - pexp(20,lambda)

##############
# Ejemplo 14 #
##############

# X = monto en soles del ahorro de un cliente
# X ~ Exp(0.00025)

# Mediana de X: x_0.25
qexp(0.50,0.00025)

# p = P(cliente es preferencial)
#   = P(X>5000)
#   = 1 - F_X(5000)

p = 1 - pexp(5000,0.00025)

# Y = número de clientes preferenciales en 6 asignados
# Y ~ Binomial(6,p)
# P(Y>=2) = 1 - P(Y<=1)
#         = 1 - F_Y(1)
#         = 1 - f_Y(0) - f_Y(1)

1 - pbinom(1,6,p)
1 - sum(dbinom(0:1,6,p))

##############
# Ejemplo 15 #
##############

# Proceso de Poisson: ocurrencia de terremotos en el tiempo
# Tasa de ocurrencia
lambda = 1/20 # terremotos por año

# x = tiempo entre el primer y cuarto terremoto
# X ~ Gamma(alpha=3,lambda=1/20)
# E(X) = alpha/lambda
alpha=3
alpha/lambda

# Y = tiempo hasta que ocurra el segundo terremoto
# Y ~ Gamma(alpha=2,lambda=1/20)
# P(Y>40) = 1 - F_Y(40)
1-pgamma(40,2,1/20)


##############
# Ejemplo 16 #
##############

# X = consumo en miles de kwh de una fábrica
# X ~ Gamma(alpha,lambda)
#   E(X) = alpha/lambda = 2
# Var(X) = alpha/lambda^2 =2

# Entonces, alpha = 2 y lambda = 2
# X ~ Gamma(alpha=2,lambda=1)

# P(X>4|X>2) =  P(X>4)   1-F_x(4)
#               ------ = --------
#               P(X>2)   1-F_x(2)

(1-pgamma(4,2,1))/(1-pgamma(2,2,1))

# p = P(X>2) = 1-F_x(2)
# Y = número de fábricas que tienen un consumo mayor
#     de 2 mil kwh de las 5 seleccionadas
# Y ~ Binomial(5,p)
# P(Y=1) = f_Y(1)
p = 1-pgamma(2,2,1)
dbinom(1,5,p)

##############
# Ejemplo 17 #
##############

# X ~ N(70,10)
# P(X<60)
pnorm(60,70,10)

#     x - 70
# Z = ------ ~ N(0,1)
#       10
#                X-70    60-70
# P(X < 60) = P(------ < -----) = P(Z<-1)
#                 10       10
pnorm(-1)

1-pnorm(95,70,10)
1-pnorm(2.5)

pnorm(80,70,10)-pnorm(50,70,10)
pnorm(1)-pnorm(-2)


##############
# Ejemplo 18 #
##############

# X = demanda semanal de fierro
# X ~ N(650,100^2)

# P(X<=500)
pnorm(500,650,100)

# c = cantidad de fierro en la tienda
# P(X<=c) = 0.8980
#  F_X(c) = 0.8980
# Entonces, c es el cuantil 0.8990 de X,
# esto es, x_0.8980

qnorm(0.8980,650,100)

##############
# Ejemplo 19 #
##############

# P(X<8)
pnorm(8,5,3)

# P(Y<8)
pnorm(8,7,0.9)

# C_A = 50X + 25+30X^2
# mu_X = E(X) = 5
# sigma_x = Var(X)^{1/2} = 3
# E(C_A) = 50E(X) + 25 + 30E(X^2)
#        = 50(mu_x) + 25 + 30(sigma_X^2+mu_x^2)
mu_X    = 5
sigma_X = 3 

50*mu_X + 25 + 30*(mu_X^2+sigma_X^2) 

# C_B = 50Y + 10 + 20Y^2
# mu_X = E(Y) = 7
# sigma_x = Var(Y)^{1/2} = 0.9
# E(C_B) = 50E(Y) + 10 + 20E(Y^2)
#        = 50(mu_Y) + 25 + 30(sigma_Y^2+mu_Y^2)
mu_Y    = 7
sigma_Y = 0.9 

50*mu_Y + 10 + 20*(mu_Y^2+sigma_Y^2) 


##############
# Ejemplo 20 #
##############

# Lectura de datos
d = read.csv("caudal.csv")

# Gráfico de cuantiles: Exp(1)
cuantil_muestral    = sort(d$caudal)
cuantil_poblacional = qexp(ppoints(d$caudal),1/4)  
plot(cuantil_poblacional,cuantil_muestral)
abline(0,1,col=2,lwd=2)

# Gráfico de cuantiles: Gamma(4,1)
cuantil_muestral    = sort(d$caudal)
cuantil_poblacional = qgamma(ppoints(d$caudal),4,1)  
plot(cuantil_poblacional,cuantil_muestral)
abline(0,1,col=2,lwd=2)

# Gráfico de cuantiles: Normal(4,2^2)
cuantil_muestral    = sort(d$caudal)
cuantil_poblacional = qnorm(ppoints(d$caudal),4,2)  
plot(cuantil_poblacional,cuantil_muestral)
abline(0,1,col=2,lwd=2)


# Gráfico de función de densidad empírica

plot(density(d$caudal,from=0),
     ylab = "Densidad",
     xlab = "x",
     main = "Función de densidad empírica",
     ylim=c(0,0.25))

curve(dexp(x,1/4),add=TRUE,col="red",n=1001)
curve(dgamma(x,4,1),add=TRUE,col="blue",n=1001)
curve(dnorm(x,4,2),add=TRUE,col="green",n=1001)

legend("topright",
       legend=c("Empírica","Exp(1)",
                "Gamma(4,1)","Normal(4,2)"),
       col=c("black","red","blue","green"),
       pch=15,bty="n")
