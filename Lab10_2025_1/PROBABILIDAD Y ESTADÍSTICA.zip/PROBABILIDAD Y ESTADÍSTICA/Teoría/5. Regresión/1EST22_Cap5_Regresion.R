# Datos: mtcars
# mpg: eficiencia en millas por galón
# hp : potencia del motor en caballos de fuerza
# am ; tipo de caja de cambio (1_mecánica,0=automática)
# wt : peso del auto en miles de libras

# Diagrama de dispersión
plot(mtcars$hp,mtcars$mpg,pch=16)

# Correlación
cor(mtcars$hp,mtcars$mpg)

#####################################
# Modelo de regresión lineal simple #
#####################################

# Estimación

# Modelo 1:
# variable respuesta: mpg
# Covariable: hp

reg =lm(mpg~hp,mtcars)
reg

# Diagrama de dispersión 
# con línea estimada
plot(mtcars$hp,mtcars$mpg,pch=16)
abline(reg,col="red",lwd=2)

# Valores ajustados
predict(reg)

# Residuales
residuals(reg)

# Coeficiente de determinación
summary(reg)$r.squared

# Modelo 2:
# variable respuesta: mpg
# Covariable: wt

# Estimación
reg2 = lm(mpg~wt,mtcars)
reg2

# Estimar mpg para wt = 3
# Directamente
37.285-5.344*3
# Usando función predict
predict(reg2,data.frame(wt=3))

# Coeficiente de determinación
summary(reg2)$r.squared

# Modelo 3:
# variable respuesta: mpg
# Covariable: am

reg3 = lm(mpg~am,mtcars)
reg3

# Coeficiente de determinación
summary(reg3)$r.squared

# Inferencia
summary(reg3)

# Intervalos de confianza para coeficientes
confint(reg3,level=0.95)

# Intervalo de confianza para respuesta media
predict(reg3,data.frame(am=1),interval="confidence")

# Intervalo de predicción
predict(reg3,data.frame(am=1),interval="predict")


#######################################
# Modelo de regresión lineal múltiple #
#######################################

# Modelo 4:
# variable respuesta: mpg
# Covariables: hp, wt

reg4 = lm(mpg~hp+wt,mtcars)
reg4 

# Suma de cuadrados de los residuales
# SCRes
deviance(reg4)

# Coeficiente de determinación
summary(reg4)$r.squared

# Coeficiente de determinación ajustado
summary(reg4)$adj.r.squared

# AIC
AIC(reg4)

# Inferencia
summary(reg4)

# Intervalos de confianza para coeficientes
confint(reg4,level=0.95)

# Intervalo de confianza para respuesta media
predict(reg4,data.frame(hp=150,wt=3),interval="confidence")

# Intervalo de predicción
predict(reg,data.frame(hp=150,wt=3),interval="predict")


# Modelo 5:
# variable respuesta: mpg
# Covariables: cyl

# Declaramos como factor cyl
mtcars$cyl =as.factor(mtcars$cyl)

# Estimación
reg5 =lm(mpg~cyl,mtcars)
summary(reg5)

# Medidas para comparación de modelos
summary(reg5)$adj.r.squared
AIC(reg5)

AIC(reg,reg2,reg3,reg4,reg5)


