# Probabilidad

# Conteo

# Factorial   : n!    : factorial(n)
# Combinación : C^n_r : choose(n,r)
# Permutación : P^n_r : choose(n,r)*factorial(r)

# Ejemplo:

# Parte a) 

# Ω = {se seleccionan al azar y sin reemplazo 3 circuitos del almacén}
# A = {se selecciona solamente un circuito inservible}

# n(Ω) = C^12_3
choose(12,3)

# n(A) = C^2_1 × C^8_2
choose(2,1) * choose(8,2)

# P(A) = n(A)/n(Ω) = C^2_1 × C^8_2 / C^12_3
choose(2,1) * choose(8,2) / choose(12,3)

# Parte b)
# B = {se selecciona al menos un ineficiente}

# Método 1
# B^c = {se selecciona ningún ineficiente}
# P(B) = 1 - P(B^c)
#      = 1 - n(B^c)/n(Ω)
#      = 1 - C^4_0 × C^8_3 / C^12_3

1 - choose(4,0) * choose(8,3) / choose(12,3)

# Método 2
# Ej = {se selecciona exactamente j circuitos ineficientes}, j = 0,1,2,3
# son eventos mutuamente excluyentes

# P(B) = P(E1 ∪ E2 ∪ E3) 
#      = P(E1) + P(E2) + P(E3)
#      = C^4_1 × C^8_2 / C^12_3 + C^4_2 × C^8_1 / C^12_3 +C^4_3 × C^8_0 / C^12_3

choose(4,1) * choose(8,2) / choose(12,3) +
choose(4,2) * choose(8,1) / choose(12,3) +
choose(4,3) * choose(8,0) / choose(12,3)

# C = {se selecciona un circuito de cada tipo
# P(C) = C^2_1 × C^2_1 × C^8_2 / C^12_3

choose(4,1) * choose(2,1) * choose(8,1) / choose(12,3)

# Ejemplo

# E = {obtener un par en una mano de poker}

# Principio de multiplicación
# F1 = {seleccionar un número para el par}
# F2 = {seleccionar los símbolos para el par}
# F3 = {seleccionar los números de las otras cartas}
# F4 = {seleccionar los símbolos de las otras cartas}

# P(E) = n(E) / n(Ω)
#      = n(F1) × n(F2) × n(F3) × n(F4) / n(Ω)

choose(13,1) * 
choose(4,2) *
choose(12,3) *
choose(4,1)^3 /
choose(52,5)  

# Ejemplo

# E  = {seleccionar un circuito defectuoso}
# Dj = {seleccionar un circuito defectuoso en la j-ésima elección}, j =1,2,3
# Bj = {seleccionar un circuito no defectuoso en la j-ésima elección}, j =1,2,3

# P(E) = P(D1∩B2∩B3) + P(B1∩D2∩B3) + P(B1∩B2∩D3)  
#      = P(D1)P(B2|D1)P(B3|D1∩B2) +
#        P(B1)P(D2|B1)P(B3|B1∩D2) +
#        P(B1)P(B2|B1)P(D3|B1∩B2) +
  
(4/10)*(6/9)*(5/8) +
(6/10)*(4/9)*(5/8) +
(6/10)*(5/9)*(4/8)

# Ejemplo

# A = { primer día puede tener nivel de contaminación del aire aceptable }
# B = { segundo día puede tener nivel de contaminación del aire aceptable }
# A y B son eventos independientes

# P(A) = 0.4
# P(B) = 0.3
pA = 0.4
pB = 0.3

# P(A∩B) = P(A)P(B)
pA*pB

# P(A∪B) = P(A) + P(B) -P(A∩B) 
pA + pB - pA*pB

# P((A∩B^c)∪(A^c∩B)) = P(A^c∩B) + P(A∩B^c) por ser mutuamente excluyentes
#                = P(A^c)P(B) +P(A)P(B^c)
(1-pA)*pB + pA*(1-pB)

# P(A^c∩B^c) = P(A^c)P(B^c)
(1-pA)*(1-pB)

# Ejemplo

# A1 = {la persona tiene la enfermedad}
# A2 = {la persona no tiene la enfermedad}
# A1 y A2: partición del espacio muestral

# B = {la persona da positivo a la prueba}

# P(A1) = 0.005
# P(A2) = 0.995
p = c(0.005,0.995)

# P(B|A1) = 0.99
# P(B|A2) = 0.99
q = c(0.99,0.01)


# P(B) = Σ P(A_j)P(B|Aj)  por  el teorema de probabilidad total
sum(p*q)

# P(A1|B) = P(A1)P(B|A1) / P(B) por el teorema de Bayes
p[1]*q[1] / sum(p*q)

