# Ley fuerte de los grandes números
# X ~ Bernoulli(p)
# X_bar --> p


epsilon <- 0.01
p       <- 0.10
n       <- 5:10000

plot(n,pbinom(n*(p - epsilon),n,p) + (1-pbinom(n*(p +epsilon),n,p)),
     ylim=c(0,1),type="l",col=2,
     xlab="Tamaño de muestra (n)",
     ylab=expression(paste("P(|",bar(X)," - ",mu,"| >",epsilon,")")))
abline(h=0,lty=2)

# Teorema del límite central
# X ~ Poisson(3)
# X_bar ~aprox N(3,3/n)

n      = 30
lambda = 3
k      = 10000 # número de simulaciones

media.muestral=NULL
for(j in 1:k){
  x=rpois(n,lambda)         # Simular muestra
  media.muestral[j]=mean(x) # Calcular media muestral
}

hist(media.muestral,prob=TRUE,breaks=30,
     xlab=paste("Media muestral (n=",n,")",sep=""),
     ylab="Densidad",
     main="")
curve(dnorm(x,lambda,sqrt(lambda/n)),col=2,lwd=3,add=TRUE)

# Estimación por Máxima Verosimilitud
# Lectura de datos
datos = read.csv("tiempo_de_falla.csv")

# L(beta): Función de verosimilitud
#          Modelo Exponencial
L_exp=function(beta,x){
  n  = length(x)
  sx = sum(x)
  exp(-sx/beta)/beta^n
}

L_exp(1,datos$tiempo)

L_exp = function(beta,x){
  prod(dexp(x,1/beta))
}

L_exp(1,datos$tiempo)

# Gráfico de L(beta)
b  = seq(0,4,0.01)
Lb = NULL
for(h in 1:length(b)){
  Lb[h] =  L_exp(b[h],datos$tiempo)
}

plot(b,Lb,type="l",col=2,lwd=2)


# L(beta): Función de log-verosimilitud
#          Modelo Exponencial

l_exp=function(beta,x){
  n  = length(x)
  sx = sum(x)
  l  = -n*log(beta)-sx/beta
  return(-l)
}

l_exp(1,datos$tiempo)

l_exp = function(beta,x){
  sum(dexp(x,1/beta,log = TRUE))
}

l_exp(1,datos$tiempo)


# Gráfico de l(beta)
b  = seq(0.3,4,0.01)
lb = NULL
for(h in 1:length(b)){
  lb[h] =  l_exp(b[h],datos$tiempo)
}

plot(b,-lb,type="l",col=2,lwd=2)

# EMV

(beta_hat =  mean(datos$tiempo))

abline(v=beta_hat,lwd=2,col=4)
abline(h=-l_exp(beta_hat,datos$tiempo),lwd=2,col=3)

# EMV - Métodos numéricos

# Definir una función que calcule 
# el negativo de la función de log-verosmilitud

l_exp = function(beta,x){
  -sum(dexp(x,1/beta,log = TRUE))
}

# Usando función optim

optim(par    = 2,
      fn     = l_exp,
      method = "L-BFGS-B",
      lower  = 0,
      upper  = Inf,
      x      = datos$tiempo)


# Usando función nlminb

nlminb(start     = 1.5,
       objective = l_exp,
       lower     = 0,
       upper     = Inf,
       x         = datos$tiempo)

# Modelo vs Datos

plot(density(datos$tiempo),lwd=3,
     xlab="Tiempo de duración",
     ylab="Densidad",
     main="")
curve(dexp(x,beta_hat),add=TRUE,col=2,lwd=3)
legend("topleft",legend=c("Datos","Modelo Exponencial"),
       col=c(1,2),pch=15,bty="")

# EMV
(mv_exp=nlminb(start = 1.5,
               objective = l_exp,
               lower = 0, upper     = Inf,
               x = datos$tiempo))

# Log-verosimilitud
(l_hat_exp = -mv_exp$objective)
# Número de parámetros
k_exp = 1
# AIC
(AIC_exp = -2*l_hat_exp + 2*k_exp)

#########################################################
#  Modelo Gamma

# Definir una función que calcule 
# el negativo de la función de log-verosmilitud

l_gamma=function(theta,x){
  alpha = theta[1]
  beta  = theta[2]
  l     = -n*log(gamma(alpha))-n*alpha*log(beta)+
          (alpha-1)*sum(log(x))-sum(x)/beta
  return(-l)
}


l_gamma = function(theta,x){
  alpha= theta[1]
  beta = theta[2]
  l    = sum(dgamma(x,alpha,1/beta,log = TRUE))
  return(-l)
}


l_gamma(c(15,0.05),datos$tiempo)

# Usando función optim

optim(par    = c(20,0.1),
      fn     = l_gamma,
      method = "L-BFGS-B",
      lower  = c(0,0),
      upper  = c(Inf,Inf),
      x      = datos$tiempo)


# Usando función nlminb

nlminb(start     = c(20,0.1),
       objective = l_gamma,
       lower     = c(0,0),
       upper     = c(Inf,Inf),
       x         = datos$tiempo)

# EMV

(mv_gamma=nlminb(start     = c(20,0.1),
                 objective = l_gamma,
                 lower     = c(0,0),
                 upper     = c(Inf,Inf),
                 x         = datos$tiempo))

# EMV de alpha y beta

mv_gamma$par

# Log-verosimilitud
(l_hat_gamma = -mv_gamma$objective)

# Número de parámetros
k_gamma = 2

# AIC
(AIC_gamma = -2*l_hat_gamma + 2*k_gamma)

# Modelos vs Datos

plot(density(datos$tiempo),lwd=3,
     xlab="Tiempo de duración",
     ylab="Densidad",
     main="")
curve(dexp(x,beta_hat),add=TRUE,col=2,lwd=3)
curve(dgamma(x,mv_gamma$par[1],1/mv_gamma$par[2]),add=TRUE,col=3,lwd=3)
legend("topleft",
       legend=c("Datos","Modelo Exponencial","Modelo Gamma"),
       col=c(1,2,3),pch=15,bty="")


#########################################################
#  Modelo Weibull

# Definir una función que calcule 
# el negativo de la función de log-verosmilitud

l_weibull = function(theta,x){
  alpha = theta[1]
  beta  = theta[2]
  l     = sum(dweibull(x,alpha,beta,log = TRUE))
  return(-l)
}


# Usando función optim

optim(par    = c(1,1),
      fn     = l_weibull,
      method = "L-BFGS-B",
      lower  = c(0,0),
      upper  = c(Inf,Inf),
      x      = datos$tiempo)


# Usando función nlminb

nlminb(start     = c(1,1),
       objective = l_weibull,
       lower     = c(0,0),
       upper     = c(Inf,Inf),
       x         = datos$tiempo)

# EMV

(mv_weibull=nlminb(start     = c(1,1),
                   objective = l_weibull,
                   lower     = c(0,0),
                   upper     = c(Inf,Inf),
                   x         = datos$tiempo))

# EMV de alpha y beta
mv_weibull$par

# Log-verosimilitud
(l_hat_weibull = -mv_weibull$objective)

# Número de parámetros
k_weibull = 2

# AIC
(AIC_weibull = -2*l_hat_weibull + 2*k_weibull)

# Modelos vs Datos

plot(density(datos$tiempo),lwd=3,
     xlab="Tiempo de duración",
     ylab="Densidad",
     main="")
curve(dexp(x,beta_hat),add=TRUE,col=2,lwd=3)
curve(dgamma(x,mv_gamma$par[1],1/mv_gamma$par[2]),add=TRUE,col=3,lwd=3)
curve(dweibull(x,mv_weibull$par[1],mv_weibull$par[2]),add=TRUE,col=4,lwd=3)
legend("topleft",
       legend=c("Datos","Modelo Exponencial","Modelo Gamma","Modelo Weibull"),
       col=c(1,2,3,4),pch=15,bty="")

# Distribución t-Student

curve(dnorm,-4,4,
      ylab="Densidad",lwd=2)
curve(dt(x,20),add=TRUE,col="green",lwd=2)
curve(dt(x,10),add=TRUE,col="blue",lwd=2)
curve(dt(x,5),add=TRUE,col="red",lwd=2)

legend("topleft",
       legend=c("Normal","t(20)","t(10)","t(5)"),
       col=c("black","green","blue","red"),
       pch=15)


# IC para la media
# Simulación
set.seed(100)

# Población: X ~ Normal(mu=50,sigma=3^2)
mu    = 50
sigma =  3

# Tamaño de muestra
n = 40

# Simulación de intervalos
k  = 100  # número de simulaciones
L1 = NULL # Límite inferior
L2 = NULL # Límite superior

for(i in 1:k){
  muestra = rnorm(n,mu,sigma)      # muestra aleatoria
  x.bar   = mean(muestra)    # media muestral
  s       = sd(muestra)       # desviación estándar muestral
  t       = qt(0.975,n-1)     # percentil 0.975 de t(39)
  L1[i]   = x.bar-t*s/sqrt(n) # Limite inferior del IC
  L2[i]   = x.bar+t*s/sqrt(n) # Límite superior del IC
}

plot(c(1,100),c(min(L1),max(L2)),type="n",
     xlab="Simulación",
     ylab="Intervalo de confianza")
for(i in 1:100){
  if(L1[i] > mu | L2[i] < mu){
    segments(x0=i,x1=i,y0=L1[i],y1=L2[i],
             col=2,lwd=3)
    print("hola")
  }
  else segments(x0=i,x1=i,y0=L1[i],y1=L2[i])
}
abline(h=mu,lwd=3,col=4)


# IC para la media
# Simulación
set.seed(800)

# Población: Exponencial(beta=0.02) ==> mu = 1/beta = 50
beta  = 0.02

# Tamaño de muestra
n = 40

# Simulación de intervalos
k  = 100  # número de simulaciones
L1 = NULL # Límite inferior
L2 = NULL # Límite superior

for(i in 1:k){
  muestra = rexp(n,beta)      # muestra aleatoria
  x.bar   = mean(muestra)    # media muestral
  s       = sd(muestra)       # desviación estándar muestral
  t       = qt(0.975,n-1)     # percentil 0.975 de t(39)
  L1[i]   = x.bar-t*s/sqrt(n) # Limite inferior del IC
  L2[i]   = x.bar+t*s/sqrt(n) # Límite superior del IC
}

plot(c(1,100),c(min(L1),max(L2)),type="n",
     xlab="Simulación",
     ylab="Intervalo de confianza")
for(i in 1:100){
  if(L1[i] > mu | L2[i] < mu){
    segments(x0=i,x1=i,y0=L1[i],y1=L2[i],
             col=2,lwd=3)
    print("hola")
  }
  else segments(x0=i,x1=i,y0=L1[i],y1=L2[i])
}
abline(h=mu,lwd=3,col=4)


######################################
# Ejemplo IC para la media           #
######################################

# Lectura de datos
x=c(0.33, 7.59, 4.38, 4.92, 2.86, 4.97, 8.14, 3.28, 2.72)

# Cálculo de estadísticas
x.bar=mean(x)
s=sd(x)
n=length(x)

n
x.bar
s

# varianza poblacional sigma^2
sigma=2

# Nivel de confianza 1-alpha = 0.95
alpha=0.05

# Cuantil 1-alpha/2 de N(0,1)
z=qnorm(1-alpha/2)
z

# IC al 95% para mu
# Población normal, varianza conocida
x.bar-z*sigma/sqrt(n)
x.bar+z*sigma/sqrt(n)

# IC al 95% para mu
# Población normal, varianza conocida

# IC usando función z.test
require(BSDA)
z.test(x,sigma.x = 2,conf.level = 0.95)

##########################################
# Tamaño de muestra

# Nivel de confianza 1-alpha=0.99
alpha=0.01

# Cuantil 1-alpha/2 de N(0,1)
z=qnorm(1-alpha/2)
z

# Máximo error de estimación (margen de error)
e=0.5

# Tamaño de muestra, redondeando por exceso
n=ceiling(z^2*sigma^2/e^2)
n

##########################################
n=9

# Cuantil 1-alpha/2 de t(n-1)
t = qt(0.975,n-1)
t

# IC al 95% para mu
# Población normal, varianza conocida
x.bar-t*s/sqrt(n)
x.bar+t*s/sqrt(n)

# IC usando función t.test
t.test(x,conf.level = 0.95)


##################################
# IC para una proporción         #
##################################

#Tamaño de muestra
n=81

# proporción muestral
p.bar = 38/81

# Nivel de confianza 1-alpha = 0.95
alpha=0.05

# cuantil de Z ~ N(0,1)
z=qnorm(1-alpha/2)
z

# Intervalo de confianza
p.bar-z*sqrt(p.bar*(1-p.bar)/n)
p.bar+z*sqrt(p.bar*(1-p.bar)/n)

# IC usando función prop.test
prop.test(x=38,n=81,conf.level = 0.95)

#################
# Muestra
n=38
x.bar=850
s=80

# Nivel de confianza
alpha=0.01
z=qnorm(1-alpha/2)

# límite
lim=900

# Aumento
lim-x.bar+z*s/sqrt(n)

###########################
# Tamaño de muestra población infinita
# Nivel de confianza 1-alpha=0.95
alpha=0.05
# Error máximo de estimación
e=0.025

# Cuantil Z_1-alpha/2
z=qnorm(1-alpha/2)

# Al no haber información se toma el 
# peor caso posible (mayor tamaño de muestra)
p.bar=0.5

# Cálculo del tamaño de muestra
n=ceiling(z**2*p.bar*(1-p.bar)/e**2)
n

#######################
# Tamaño de muestra población finita

# Tamaño de la población
N=1200
# Cálculo del tamaño de muestra
n0=z**2*p.bar*(1-p.bar)/e**2
n=ceiling(n0*N/(n0+N-1))
n

####################################
# Prueba de hipótesis              #
####################################

# Hipótesis
# H0: mu = 1
# H1: mu > 1

# Estadística de prueba: x.bar

# Si H0 es verdadera
# x.bar ~ N(1,0.2^2/25)

curve(dnorm(x,1,0.2/sqrt(25)),0.8,1.2,
      ylab = "Densidad")


# alpha  = P(Rechazar H0) si H0 es verdadera
#        = P(x.bar>C) si x.bar ~ N(1,0.2^2/25)

C = qnorm(0.95,1,0.2/sqrt(25))
C  

abline(h=0)
abline(v=C,col="blue")

# Se observa x.bar = 1.075
points(1.075,0,pch=16,cex=1,col="red")

# Conclusión: se rechaza H0


# Población
# Parámetros:
# mu      = media de la cantidad de producto en las bolsas 

# Muestra:
x=c(
  200.8,201.2,194.1,193.6,195.8,201.8,203.4,197.5,201.2,193.2,
  201.1,201.4,202.0,203.8,199.1,196.9,208.3,205.3,202.1,193.5,
  195.1,198.2,191.0,203.8,203.9,196.0,200.7,199.7,202.0,198.7  
)

# Estadísticas:
n=length(x)
x.bar=mean(x)
s.x=sd(x)

n
x.bar
s.x

#####################################
# Prueba de hipótesis para la media
# varianza conocida sigma = 2
sigma = 2

# Planteamiento de las hipótesis
# H0: mu = mu0
# H1: mu != mu0

mu0=205

# Nivel de significación
alpha=0.01

# Cálculo de Estadística de Prueba
Z.obs= (x.bar-mu0)/(sigma/sqrt(n))
Z.obs

# Regla de decisión
# Rechazar H0 si T.obs > t_1-alpha/2,n-1

qnorm(1-alpha/2)

# p-valor = 2*P(T>T.obs)
2*(1-pnorm(abs(Z.obs)))

# Prueba de hipótesis en R
z.test(x,mu=205,sigma.x = 2,alternative = "two.sided")

####################################
# Prueba de hipótesis para la media
# varianza desconocida 

# Planteamiento de las hipótesis
# H0: mu = mu0
# H1: mu != mu0

mu0=205

# Nivel de significación
alpha=0.01

# Cálculo de Estadística de Prueba
T.obs= (x.bar-mu0)/(s.x/sqrt(n))
T.obs

# Regla de decisión
# Rechazar H0 si T.obs > t_1-alpha/2,n-1

qt(1-alpha/2,n-1)

# p-valor = 2*P(T>T.obs)
2*(1-pt(abs(T.obs),n-1))

# Prueba de hipótesis en R
t.test(x,mu=205,alternative = "two.sided")

############################################33
# Población
# p = proporción de bolsas con peso menor al nominal

# Muestra
# Número de éxitos
y=sum(x<200)
# Tamaño de muestra
n=length(x)

# Proporción muestral
p.bar=y/n

# Planteamiento de las hipótesis
# H0: p = p0
# H1: p > p0
p0=0.4

# Nivel de significación
alpha=0.05

# Cálculo de la estadística de prueba
Z.obs=(p.bar-p0)/sqrt(p0*(1-p0)/n)
Z.obs

# Regla de decisión
# Rechazar H0 si Z.obs > Z_1-alpha
qnorm(1-alpha)

# p-valor
1-pnorm(Z.obs)

# Prueba de hipótesis en R
prop.test(y,n,p=0.4,alternative = "greater")

###################################################
###################################################

# Población
# mu      = media de la resistencia a la rotura de los tubos
#           de desagüe del fabricante      
# sigma^2 = varianza de la resistencia a la rotura de los tubos
#           de desagüe del fabricante 

# Muestra:
x=c(2610,2750,2420,2510,2540,2490,2680)

# Estadísticas
n=length(x)
x.bar=mean(x)
s.x=sd(x)

n
x.bar
s.x

# Prueba de hipótesis para la media

# Planteamiento de las hipótesis
# H0: mu = mu0
# H1: mu > mu0
mu0=2500

# Nivel de significación
alpha = 0.05

# Cálculo de la estadística de prueba
T.obs=(x.bar-mu0)/(s.x/sqrt(n))
T.obs

# Regla de decisión
# Rechazar H0 si T.obs > T_1-alpha,n-1
qt(1-alpha,n-1)

# p-valor
1-pt(T.obs,n-1)

# Prueba de hipótesis en R
t.test(x,mu=2500,alternative = "greater")
