
M <- 20                  # Número de máquinas
t_contrato <- 30         # Duración del contrato en días
N_sim <- 10000           # Número de simulaciones

# Función de la utilidad por máquina
calcular_utilidad <- function(T_falla, t_contrato) {
  # T_falla es la simulación del tiempo hasta la primera falla
  if (T_falla > t_contrato) {
    return(2700)
  } else {
    return(100 * T_falla - 300)
  }
}

# Simulamos las utilidades

# Almacenamos la utilidad total de las 20 máquinas para cada una de
# las 10000 simulaciones
utilidades_totales <- numeric(N_sim)

for (i in 1:N_sim) {
  #Generamos 20 valores aleatorios uniformes
  U <- runif(M)
  
  # Simulamos el tiempo hasta la primera falla para las 20 máquinas
  T_falla <- sqrt(-56.25 * log(U))
  
  # Calculamos la utilidad para cada una de las 20 máquinas
  utilidad_maquinas <- sapply(T_falla, calcular_utilidad, t_contrato)
  
  # La utilidad total de la simulación presente es la suma de las utilidades de 
  # las 20 máquinas
  utilidades_totales[i] <- sum(utilidad_maquinas)
}

# Resultados obtenidos
promedio <- mean(utilidades_totales)
desviacion_estandar <- sd(utilidades_totales)

# Impresión de resultados
cat(paste("Promedio de utilidades total:", round(promedio, 4), "soles\n"))
cat(paste("Desviación estándar de utilidades total :", round(desviacion_estandar, 4), "soles\n"))