set.seed(20220563)

#Simular X

n <- 10000

u <- runif(n)

x_i <- (1 - (1 - u)^(1/3))^(1/3)

head(x_i)
x_i

#Simular Y

alpha <- 0.5
theta_verdadero <- 2

beta_i <- 1 + theta_verdadero * x_i


y_i <- rweibull(n, shape = alpha, scale = beta_i)


datos_simulados <- data.frame(x = x_i, y = y_i)


head(datos_simulados)


# Para que el código sea más legible, guardemos los vectores
x <- datos_simulados$x
y <- datos_simulados$y

#Definir g y hallar el costo neto esperado


tramo_1 <- 2 + (1 + 2*x - y)^0.8 * exp(x / (1 + y))
tramo_2 <- log(1 + y^2) - x / (1 + y) + 1
tramo_3 <- sqrt(y) / (1 + x^2) + (x^2 * (y > 5)) + 0.5
g_i <- ifelse(y <= (1 + 2*x), tramo_1, ifelse(y <= 3, tramo_2, tramo_3))

gamma_hat <- mean(g_i)

s_g <- sd(g_i)
error_estandar_hat <- s_g / sqrt(n)

print(paste("Costo Neto Esperado (gamma_hat):", gamma_hat))
print(paste("Error Estándar Estimado (se_hat):", error_estandar_hat))

