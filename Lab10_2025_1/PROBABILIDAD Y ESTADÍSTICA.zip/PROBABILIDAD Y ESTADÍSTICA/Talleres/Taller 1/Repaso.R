
#Este comando lee un archivo csv y el argumento es la dirección completa del archivo
datos=read.csv("C:/Users/Franklin/OneDrive/6to ciclo/PROBABILIDAD Y ESTADÍSTICA/Talleres/Taller 1/datos_bmi.csv")

#Se presentarán las primeras filas del objeto en la consola y así se verifica la correcta lectura del archivo
head(datos)

#Sirve para acceder a los datos de la variable bmi, "bmi" es referencial pues puede ser otro nombre
datos$bmi
datos$edad.papa
datos$edad.mama

#Sirve para imprimir todos los datos de una misma columna, 'x' indica el número de columna
datos[,1]
datos[,1]
datos[,2]
datos[,3]

#Sirve para imprimir desde la primera fila de datos hasta la quinta, 1 y 5 pueden ser otros números mayores a cero
datos[1:5,]

#Sirve para imprimir las filas 1, 4 y 5, estos pueden ser otros números mayores a 0
datos[c(1,4,5),]

#Imprime las filas que cumplen la condición señalada - '&' un operador lógico conjuntivo
datos[datos$bmi>40,]
datos[datos$bmi<40 & datos$edad>50,]
datos[datos$bmi<40 & datos$edad>35,]

#Se crea un nuevo dato que cumple la condición descrita
datosH=datos[datos$sexo=="Hombre",]

head(datosH)

#Estadística resumen para el índice de masa corporal tanto de hombres como mujeres
summary(datos$bmi[datos$sexo=="Hombre"])
summary(datos$bmi[datos$sexo=="Mujer"])

#Se grafican 2 histogramas para compararlas
par(mfrow=c(1,2))
hist(datos$bmi[datos$sexo=="Hombre"])
hist(datos$bmi[datos$sexo=="Mujer"])

#Escalar numérico
a=1
a

#Vector numérico
b=c(1,5,9)
b

#Vector de caracteres
d=c("a","b","c")
d

#Vector lógico definido directamente
e=c(TRUE,TRUE,FALSE)
e

#Vector lógico definido por una operación
f=b>3
f

#Los datos perdidos se denotan por NA
g=c(1,2,3,NA,1)
g

#IF ELSE

#Ejemplo 1
a<-5
if(a<0){
  b=2*a
  print(b)
}else{
  b=3*a
  print(b)
}

#Ejemplo 2 - Posiblemente esté mal implementado
x<-c(1,2,3,4,5,6)
y<-if else (x<4,0,1)
x

#FOR

#Ejemplo 1
for(i in 1:3) cat("hola","\n")

#Ejemplo 2
x<-c(1,2,3,4,5)
y<-NULL
for(i in 1:5)y[i]<-2*x[i]
y

#WHILE

#Ejemplo 1
n=5
y=i=1
while (i<=n) {
  y=y*i
  i=i+1
}
y

#DEFINIR FUNCIONES

#Ejemplo 1
media <- function(x){
  suma <- sum(x)    #suma
  n    <- length(x) #número de elementos
  media<- suma/n    #calcula media
  media
}

media(datos$bmi)

#Ejemplo 2
media <- function(x){
  suma <- sum(x)    #suma
  n    <- length(x) #número de elementos
  media<- suma/n    #calcula media
  return(list(media=media,suma=suma,n=n))
}

media(datos$bmi)

#Ejemplo 3
medias <- function(x,y){
  suma.x <- sum(x)     #suma de x
  n.x    <- length(x)  #número de elementos de x
  media.x<- suma.x/n.x #calcula media de x
  suma.y <- sum(y)     #suma de y
  n.y    <- length(y)  #número de elementos de y
  media.y<- suma.y/n.y #calcula media dey
  return(list(media.x=media.x,media.y=media.y))
}

medias(datos$bmi,datos$edad)
