datos=read.csv("datos_bmi.csv")
dim(datos)
head(datos)

datos$bmi
datos[,1]

datos[1:5,]
head(datos)

datos[c(1,4,5),]

datos[datos$bmi>40,]

datos[datos$bmi<40 & datos$edad>50,]

datos[datos$bmi<40 & datos$edad.papa>80,]

str(datos)
datosM=datos[datos$sexo=="Mujer",]
head(datosM)

datosH=datos[datos$sexo=="Hombre",]
head(datosH)

help(str)

summary(datos$bmi[datos$sexo=="Hombre"])
summary(datos$bmi[datos$sexo=="Mujer"])

par(mfrow=c(1,2))
hist(datos$bmi[datos$sexo=="Hombre"])
hist(datos$bmi[datos$sexo=="Mujer"])

media <- funtion(x) {
  suma  <-  sum(x)
  n     <-  length(x)
  media <-  suma/n
  media
}

media(datos$bmi)

choose(7,2)*choose(3,0)/choose(10,2)
(choose(4,1)*choose(1,0)*choose(3,1)*choose(2,0))/choose(5,1)*choose(5,1)
